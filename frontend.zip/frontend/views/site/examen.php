

<?php
/* @var $this yii\web\View */
$this->title = 'PUCESE';
?>

<div class="site-index">

    <div class="container-fluid">

    <div class="row">

    <div class="col-sm-2">

        <a class="btn btn-primary" href="http://fre1221.thefreecpanel.com/frontend/web/index.php" target="_blank" >EXAMEN</a>
   
    </div>

        
    </div>

</div>

</div>
