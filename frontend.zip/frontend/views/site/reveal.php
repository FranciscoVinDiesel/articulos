
<div class="panel-group">
    <!--div class="panel panel-info"-->
    <!--div class="panel-heading"> <h3 class="panel-title">Testing</h3> </div-->
    <div class="panel-body">
      <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="http://fre1234.thefreecpanel.com/frontend/views/reveals/#/"></iframe>
    </div>
    </div>
    <!--/div-->
</div>
